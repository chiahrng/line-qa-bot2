import os, json
from flask import Flask, request
from dotenv import load_dotenv
from linebot import LineBotApi, WebhookHandler
from linebot.models import MessageEvent, TextMessage, TextSendMessage
import openai

# 初始化
load_dotenv("config.env")
app = Flask(__name__)
line_bot_api = LineBotApi(os.getenv("LINE_CHANNEL_ACCESS_TOKEN"))
handler = WebhookHandler(os.getenv("LINE_CHANNEL_SECRET"))
openai.api_key = os.getenv("OPENAI_API_KEY")

HISTORY_FILE = "chat_history.json"

def load_history():
    if not os.path.exists(HISTORY_FILE):
        return []
    with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_message(user, text):
    history = load_history()
    history.append({"user": user, "text": text})
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history[-100:], f, ensure_ascii=False, indent=2)

def retrieve_context(question):
    history = load_history()
    return "\n".join([msg["text"] for msg in history if any(word in msg["text"] for word in question.split())])

def generate_answer(question, context):
    prompt = f"以下是群組的對話紀錄：\n{context}\n\n根據以上內容，請回答以下問題：\n{question}"
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message["content"]

@app.route("/callback", methods=["POST"])
def callback():
    signature = request.headers["X-Line-Signature"]
    body = request.get_data(as_text=True)
    handler.handle(body, signature)
    return "OK"

@handler.add(MessageEvent, message=TextMessage)
def handle_text(event):
    user_id = event.source.user_id
    message = event.message.text
    save_message(user_id, message)

    if "？" in message or "?" in message:
        context = retrieve_context(message)
        answer = generate_answer(message, context or "（無相關對話）")
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=answer)
        )

if __name__ == "__main__":
    app.run(port=5000)
